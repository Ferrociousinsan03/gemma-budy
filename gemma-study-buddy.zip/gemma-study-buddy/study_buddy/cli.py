"""Command-line interface: python -m study_buddy.cli notes.txt --mode quiz"""
import argparse
import sys
from pathlib import Path

from .client import DEFAULT_MODEL, generate
from .prompts import MODES, build_prompt


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="study-buddy", description=__doc__)
    p.add_argument("file", help="Path to a text/markdown notes file")
    p.add_argument("--mode", choices=MODES, default="summary")
    p.add_argument("--model", default=DEFAULT_MODEL, help="Ollama model name")
    args = p.parse_args(argv)

    path = Path(args.file)
    if not path.is_file():
        print(f"File not found: {path}", file=sys.stderr)
        return 1
    try:
        print(generate(build_prompt(path.read_text(encoding="utf-8"), args.mode), args.model))
    except (ValueError, RuntimeError) as err:
        print(f"Error: {err}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
