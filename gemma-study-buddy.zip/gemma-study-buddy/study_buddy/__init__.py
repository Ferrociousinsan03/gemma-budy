"""Gemma Study Buddy: turn notes into summaries, quizzes and flashcards."""
__version__ = "0.1.0"
