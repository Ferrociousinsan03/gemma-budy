"""Prompt templates for each study mode."""

MODES = {
    "summary": "Summarize the notes below in 5 concise bullet points.",
    "quiz": "Create 5 multiple-choice questions (A-D) from the notes below. "
            "Put the correct answers at the end under 'Answers:'.",
    "flashcards": "Create 8 flashcards from the notes below. "
                  "Format each as 'Q: ... | A: ...', one per line.",
}


def build_prompt(notes: str, mode: str = "summary") -> str:
    if mode not in MODES:
        raise ValueError(f"Unknown mode '{mode}'. Choose from: {', '.join(MODES)}")
    if not notes.strip():
        raise ValueError("Notes are empty.")
    return f"{MODES[mode]}\n\n--- NOTES ---\n{notes.strip()}\n--- END ---"
