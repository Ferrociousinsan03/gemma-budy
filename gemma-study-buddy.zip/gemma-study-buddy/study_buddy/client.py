"""Tiny client for a local Gemma model served by Ollama."""
import requests

OLLAMA_URL = "http://localhost:11434/api/generate"
DEFAULT_MODEL = "gemma3:1b"


def generate(prompt: str, model: str = DEFAULT_MODEL, url: str = OLLAMA_URL) -> str:
    try:
        resp = requests.post(
            url, json={"model": model, "prompt": prompt, "stream": False}, timeout=120
        )
        resp.raise_for_status()
    except requests.ConnectionError as exc:
        raise RuntimeError(
            "Cannot reach Ollama. Install it and run: ollama pull " + model
        ) from exc
    return resp.json()["response"].strip()
