import pytest

from study_buddy import client
from study_buddy.cli import main
from study_buddy.prompts import build_prompt


def test_build_prompt_contains_notes_and_instruction():
    out = build_prompt("Photosynthesis makes sugar.", "quiz")
    assert "multiple-choice" in out and "Photosynthesis" in out


def test_invalid_mode_and_empty_notes():
    with pytest.raises(ValueError):
        build_prompt("text", "poem")
    with pytest.raises(ValueError):
        build_prompt("   ", "summary")


def test_generate_parses_response(monkeypatch):
    class Fake:
        def raise_for_status(self): pass
        def json(self): return {"response": "  hello  "}
    monkeypatch.setattr(client.requests, "post", lambda *a, **k: Fake())
    assert client.generate("hi") == "hello"


def test_cli_missing_file():
    assert main(["nope.txt"]) == 1
